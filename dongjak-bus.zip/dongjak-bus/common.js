// 동작복지카 안내 화면 공통 코드
// index.html(버스 화면)과 settings.html(설정)이 함께 씁니다.
// 설정 텍스트 읽기·쓰기, 시간표 상태 계산, 시각 표기를 담당합니다.
(function (global) {
  'use strict';

  var CACHE_KEY = 'busboard.settings';
  var PREVIEW_KEY = 'busboard.preview';
  var DAY_NAMES = ['일', '월', '화', '수', '목', '금', '토'];

  var DEFAULTS = {
    stop: '흑석종합사회복지관',
    car: '동작복지카 4호',
    days: [1, 2, 3, 4, 5],
    times: ['08:50', '09:45', '10:45', '11:15', '13:05', '13:55', '14:45', '15:35', '16:25', '17:15'],
    ready: 10,
    soon: 5,
    dwell: 5,
    approach: 60,
    lat: 37.5085,
    lon: 126.9630,
    motion: 'full',
    savedAt: ''
  };

  var LIMITS = {
    ready: [1, 60],
    soon: [1, 30],
    dwell: [1, 30],
    approach: [10, 180]
  };

  function clone(s) {
    return JSON.parse(JSON.stringify(s));
  }

  function clamp(v, lo, hi) {
    return Math.min(hi, Math.max(lo, v));
  }

  function pad(n) {
    return (n < 10 ? '0' : '') + n;
  }

  // "8:50", "08:50", "8시50" 같은 표기를 "08:50"으로 맞춥니다.
  function normalizeTimes(text) {
    var out = [];
    var re = /(\d{1,2})\s*[:시]\s*(\d{2})/g;
    var m;
    while ((m = re.exec(text)) !== null) {
      var h = parseInt(m[1], 10);
      var mi = parseInt(m[2], 10);
      if (h >= 0 && h <= 23 && mi >= 0 && mi <= 59) {
        var t = pad(h) + ':' + pad(mi);
        if (out.indexOf(t) < 0) out.push(t);
      }
    }
    out.sort();
    return out;
  }

  function cleanText(v) {
    return String(v).replace(/[`$\\]/g, '').replace(/\s+/g, ' ').trim();
  }

  // 설정 텍스트(설정 파일의 ` 사이 내용)를 읽어 설정 값으로 바꿉니다.
  function parse(text) {
    var s = clone(DEFAULTS);
    var errors = [];
    var seen = {};
    String(text || '').split(/\r?\n/).forEach(function (raw, i) {
      var line = raw.trim();
      if (!line || line.charAt(0) === '#' || line.indexOf('//') === 0) return;
      var at = line.indexOf(':');
      if (at < 0) {
        errors.push((i + 1) + '번째 줄에 ":" 표시가 없습니다: ' + line);
        return;
      }
      var key = line.slice(0, at).replace(/\s+/g, '');
      var val = line.slice(at + 1).trim();
      seen[key] = true;
      switch (key) {
        case '정류장':
          if (cleanText(val)) s.stop = cleanText(val);
          break;
        case '차량':
          if (cleanText(val)) s.car = cleanText(val);
          break;
        case '운행요일':
          var days = [];
          DAY_NAMES.forEach(function (name, d) {
            if (val.indexOf(name) >= 0) days.push(d);
          });
          s.days = days;
          break;
        case '도착시각':
          s.times = normalizeTimes(val);
          if (!s.times.length) errors.push('도착시각을 하나도 읽지 못했습니다. "08:50 09:45"처럼 적어 주세요.');
          break;
        case '나갈준비안내':
        case '곧도착':
        case '탑승유지':
        case '버스그림표시':
          var field = { '나갈준비안내': 'ready', '곧도착': 'soon', '탑승유지': 'dwell', '버스그림표시': 'approach' }[key];
          var n = parseInt(val, 10);
          if (isNaN(n)) errors.push(key + ' 값은 숫자(분)로 적어 주세요.');
          else s[field] = clamp(n, LIMITS[field][0], LIMITS[field][1]);
          break;
        case '날씨위치':
          var nums = val.match(/-?\d+(\.\d+)?/g);
          if (nums && nums.length >= 2) {
            s.lat = clamp(parseFloat(nums[0]), -90, 90);
            s.lon = clamp(parseFloat(nums[1]), -180, 180);
          } else {
            errors.push('날씨위치는 "37.5085 126.9630"처럼 위도와 경도를 적어 주세요.');
          }
          break;
        case '움직임':
          s.motion = val.indexOf('줄') >= 0 ? 'calm' : 'full';
          break;
        case '저장시각':
          s.savedAt = val;
          break;
        default:
          errors.push('모르는 항목입니다: ' + key);
      }
    });
    if (!seen['도착시각']) errors.push('도착시각 줄이 없습니다.');
    var ok = s.times.length > 0;
    return { ok: ok, settings: s, errors: errors };
  }

  function nowStamp(d) {
    d = d || new Date();
    return d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate()) + ' ' +
      pad(d.getHours()) + ':' + pad(d.getMinutes()) + ':' + pad(d.getSeconds());
  }

  // 설정 값을 사람이 메모장으로 읽고 고칠 수 있는 텍스트로 만듭니다.
  function serializeBody(s) {
    var days = s.days.slice().sort().map(function (d) { return DAY_NAMES[d]; }).join(' ');
    return [
      '정류장: ' + cleanText(s.stop),
      '차량: ' + cleanText(s.car),
      '운행요일: ' + days,
      '도착시각: ' + s.times.join(' '),
      '# 아래 숫자는 모두 분입니다',
      '나갈준비안내: ' + s.ready,
      '곧도착: ' + s.soon,
      '탑승유지: ' + s.dwell,
      '버스그림표시: ' + s.approach,
      '# 날씨를 받아 올 위치 (위도 경도)',
      '날씨위치: ' + s.lat + ' ' + s.lon,
      '# 모두 또는 줄이기',
      '움직임: ' + (s.motion === 'calm' ? '줄이기' : '모두'),
      '저장시각: ' + (s.savedAt || '')
    ].join('\n');
  }

  function serializeFile(s) {
    return [
      '// 동작복지카 안내 화면 설정 파일',
      '// 메모장으로 고칠 수 있습니다. 아래 ` 표시 두 개 사이의 줄만 고치고, ` 표시와 맨 아래 줄은 지우지 마세요.',
      '// 고친 뒤에는 버스 화면에서 F5를 누르면 바로 반영됩니다. 누르지 않아도 다음 날 새벽 3시에 반영됩니다.',
      '설정(`',
      serializeBody(s),
      '`);',
      ''
    ].join('\n');
  }

  // 설정 파일(settings.js)과 브라우저에 저장해 둔 값 중 맞는 것을 고릅니다.
  // 파일이 기준이고, 파일 쓰기에 실패해 브라우저 쪽이 더 최근일 때만 브라우저 값을 씁니다.
  function loadSettings(opts) {
    opts = opts || {};
    var result = { settings: clone(DEFAULTS), source: 'default', fileErrors: [], fileMissing: false };
    if (opts.preview) {
      var pv = null;
      try { pv = sessionStorage.getItem(PREVIEW_KEY); } catch (e) {}
      if (pv) {
        var pr = parse(pv);
        if (pr.ok) return { settings: pr.settings, source: 'preview', fileErrors: [], fileMissing: false };
      }
    }
    var fromFile = null;
    var fromCache = null;
    if (typeof global.__busSettingsText === 'string') {
      var fr = parse(global.__busSettingsText);
      result.fileErrors = fr.errors;
      if (fr.ok) fromFile = fr.settings;
    } else {
      result.fileMissing = true;
    }
    var cached = null;
    try { cached = localStorage.getItem(CACHE_KEY); } catch (e) {}
    if (cached) {
      var cr = parse(cached);
      if (cr.ok) fromCache = cr.settings;
    }
    if (fromFile && fromCache && fromCache.savedAt > fromFile.savedAt) {
      result.settings = fromCache;
      result.source = 'cache';
    } else if (fromFile) {
      result.settings = fromFile;
      result.source = 'file';
    } else if (fromCache) {
      result.settings = fromCache;
      result.source = 'cache';
    }
    return result;
  }

  function saveCache(s) {
    try { localStorage.setItem(CACHE_KEY, serializeBody(s)); return true; } catch (e) { return false; }
  }

  function toMin(hhmm) {
    var p = hhmm.split(':');
    return parseInt(p[0], 10) * 60 + parseInt(p[1], 10);
  }

  // 분(0~1439)을 "오후 1:55" 형태로 나눕니다.
  function fmt12(min) {
    min = ((min % 1440) + 1440) % 1440;
    var h = Math.floor(min / 60);
    var m = min % 60;
    var ampm = h < 12 ? '오전' : '오후';
    var h12 = h % 12;
    if (h12 === 0) h12 = 12;
    return { ampm: ampm, hm: h12 + ':' + pad(m), text: ampm + ' ' + h12 + ':' + pad(m) };
  }

  // 남은 분을 "75분" 대신 "1시간 15분"처럼 나눕니다.
  function splitRemain(min) {
    if (min < 60) return { h: 0, m: min };
    return { h: Math.floor(min / 60), m: min % 60 };
  }

  function nextOperatingDay(s, now) {
    var day = now.getDay();
    for (var k = 1; k <= 7; k++) {
      var d = (day + k) % 7;
      if (s.days.indexOf(d) >= 0) {
        return { offset: k, day: d, label: k === 1 ? '내일' : DAY_NAMES[d] + '요일' };
      }
    }
    return null;
  }

  // 지금 시각에 안내판 첫 줄이 어떤 상태인지 계산합니다.
  // state: before(운행 전) | waiting(대기) | coming(오는 중) | soon(곧 도착) | arrived(도착) | ended(운행 종료) | holiday(휴무)
  function computeState(s, now) {
    var times = s.times.map(toMin);
    var sec = now.getHours() * 3600 + now.getMinutes() * 60 + now.getSeconds();
    var dwell = s.dwell * 60;
    var r = { times: times, sec: sec, index: -1, next: -1, progress: 0, remainSec: 0, remainMin: 0, ready: false };

    if (s.days.indexOf(now.getDay()) < 0 || !times.length) {
      r.state = 'holiday';
      r.nextDay = nextOperatingDay(s, now);
      return r;
    }

    for (var i = 0; i < times.length; i++) {
      if (times[i] * 60 <= sec && sec < times[i] * 60 + dwell) {
        r.state = 'arrived';
        r.index = i;
        r.next = i + 1 < times.length ? i + 1 : -1;
        r.departMin = times[i] + s.dwell;
        r.progress = 1;
        return r;
      }
    }

    var n = -1;
    for (var j = 0; j < times.length; j++) {
      if (times[j] * 60 > sec) { n = j; break; }
    }
    if (n < 0) {
      r.state = 'ended';
      r.nextDay = nextOperatingDay(s, now);
      return r;
    }

    r.index = n;
    r.next = n + 1 < times.length ? n + 1 : -1;
    var arrive = times[n] * 60;
    r.remainSec = arrive - sec;
    r.remainMin = Math.ceil(r.remainSec / 60);
    var start = arrive - s.approach * 60;
    if (sec < start) {
      r.state = n === 0 ? 'before' : 'waiting';
      return r;
    }
    var prevDepart = n > 0 ? times[n - 1] * 60 + dwell : -Infinity;
    var from = Math.max(start, prevDepart);
    r.progress = clamp((sec - from) / Math.max(1, arrive - from), 0, 1);
    if (r.remainSec <= s.soon * 60) {
      r.state = 'soon';
    } else {
      r.state = 'coming';
      r.ready = r.remainSec <= s.ready * 60;
    }
    return r;
  }

  global.Busboard = {
    DEFAULTS: DEFAULTS,
    DAY_NAMES: DAY_NAMES,
    CACHE_KEY: CACHE_KEY,
    PREVIEW_KEY: PREVIEW_KEY,
    clone: clone,
    pad: pad,
    normalizeTimes: normalizeTimes,
    parse: parse,
    serializeBody: serializeBody,
    serializeFile: serializeFile,
    nowStamp: nowStamp,
    loadSettings: loadSettings,
    saveCache: saveCache,
    toMin: toMin,
    fmt12: fmt12,
    splitRemain: splitRemain,
    computeState: computeState
  };
})(typeof window !== 'undefined' ? window : globalThis);
